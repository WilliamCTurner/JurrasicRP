# JurrasicRP
Garrys Mod Gamemode about dinosaurs coming back to life and once again see them in gmod, this gamemode was made in nutscript
